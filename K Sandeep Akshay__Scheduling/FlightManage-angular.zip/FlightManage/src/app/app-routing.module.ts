import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ScheduleFlightComponent} from './schedule-flight/schedule-flight.component';
import{ScheduledFlightComponent} from './scheduled-flight/scheduled-flight.component';
import {ViewAllComponent} from './view-all/view-all.component';


const routes: Routes = [{ path: 'scheduleFlight', component: ScheduleFlightComponent },
                          {path:'scheduleFlight1',component:ScheduledFlightComponent},
                           {path:'viewAll',component:ViewAllComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
