import { Flight } from './flight';
import { Schedule } from './schedule';

export class ScheduledFlight {


          flight:Flight=new Flight();
          availableSeats:number;
          schedule:Schedule=new Schedule();


}
