import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import{Schedule} from '../schedule';
import { Airport } from '../airport';

@Component({
  selector: 'app-view-all',
  templateUrl: './view-all.component.html',
  styleUrls: ['./view-all.component.css']
})
export class ViewAllComponent implements OnInit {

  scheduleList:Schedule[];



  airport:Airport[];

  entries:any[];


  constructor(private service:DataService) { }

  ngOnInit(): void {


        this.service.viewAllSchedule().subscribe(data=>{


              this.scheduleList=data;

        });








  }

}
