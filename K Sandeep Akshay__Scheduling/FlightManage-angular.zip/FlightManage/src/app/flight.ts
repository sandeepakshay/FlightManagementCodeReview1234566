export class Flight {

    FlightName:string;
    carrierName:string;
     flightModel:string;
     seatCapacity:number;

     constructor(){}
}
