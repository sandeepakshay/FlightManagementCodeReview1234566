export class Airport {

          AirportName:string;
          AirportCode:string;
          AirportLocation:string;

          get Aname():string{

                return this.AirportName;
          }
          get Acode():string{

              return this.AirportCode;
          }
          get Alocation():string{

              return this.AirportLocation;
          }
}


