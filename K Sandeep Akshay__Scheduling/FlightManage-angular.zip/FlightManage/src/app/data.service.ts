import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Schedule } from './schedule';
import{Observable} from 'rxjs';
import { ScheduledFlight } from './scheduled-flight';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private http:HttpClient) { }


  create(schedule:Schedule):Observable<any>{

    return this.http.post("http://localhost:1113/addSchedule",schedule,{responseType:"text"});
}

 createScheduled(scheduledflight:ScheduledFlight):Observable<any>{

  return this.http.post("http://localhost:1113/addScheduled",scheduledflight,{responseType:"text"});
}

  viewAirport():Observable<any>
  {

     console.log("airports");
      return this.http.get("http://localhost:1113/viewAirport");

  }

  viewFlight():Observable<any>
  {

     console.log("these are flights");
      return this.http.get("http://localhost:1113/viewFlight");

  }


  viewSchedule():Observable<any>
  {

     console.log("these are schedule");
      return this.http.get("http://localhost:1113/viewSchedule");

  }

  viewAllSchedule():Observable<any>
  {

     console.log("these are all scheduled flights ");
      return this.http.get("http://localhost:1113/viewAllSchedule");

  }


}
