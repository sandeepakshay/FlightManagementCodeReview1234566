import { Component, OnInit } from '@angular/core';
import{DataService} from '../data.service';
import{Flight} from '../flight';
import{Schedule} from '../schedule';
import { ScheduledFlight } from '../scheduled-flight';

@Component({
  selector: 'app-scheduled-flight',
  templateUrl: './scheduled-flight.component.html',
  styleUrls: ['./scheduled-flight.component.css']
})
export class ScheduledFlightComponent implements OnInit {

  flights:Flight[];

  scheduleList:number[];

  scheduledFlight:ScheduledFlight=new ScheduledFlight();


  constructor(private service:DataService) { }

  ngOnInit(): void {


          this.service.viewFlight().subscribe(data=>this.flights=data);
          this.service.viewSchedule().subscribe(data=>this.scheduleList=data);


  }

  addScheduledFlight():void{

            this.service.createScheduled(this.scheduledFlight).subscribe(data=>this.scheduledFlight=data);
  }

}
