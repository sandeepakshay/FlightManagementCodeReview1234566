import { Airport } from './airport';
import { Timestamp } from 'rxjs';
import { Time } from '@angular/common';
import { Flight } from './flight';

export class Schedule {

        scheduleId:number;
        sourceAirport:Airport;
        destinationAirport:Airport;


		   ArrivalTime:String;
       DepartureTime:String;
       flight:Flight;
       availableSeats:number;

       constructor(){}

       get sId (): number {

        return this.scheduleId;

      }

      set sId (scheduleId: number) {
        this.scheduleId = scheduleId;
      }

      get sAirport():Airport{

           return  this.sourceAirport;
      }

      get dAirport():Airport{

            return this.destinationAirport;
      }


}
