import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ScheduleFlightComponent } from './schedule-flight/schedule-flight.component';
import {DataService} from './data.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import{FormsModule} from '@angular/forms';
import { ScheduledFlightComponent } from './scheduled-flight/scheduled-flight.component';
import { ViewAllComponent } from './view-all/view-all.component';


@NgModule({
  declarations: [
    AppComponent,
    ScheduleFlightComponent,
    ScheduledFlightComponent,
    ViewAllComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
  ],
  providers: [DataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
