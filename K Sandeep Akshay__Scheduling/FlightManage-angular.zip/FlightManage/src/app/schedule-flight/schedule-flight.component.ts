import { Component, OnInit } from '@angular/core';
import { Airport } from '../airport';
import {DataService} from '../data.service';
import { Schedule } from '../schedule';
import{Flight} from '../flight';
import { ScheduledFlight } from '../scheduled-flight';
import { Router } from '@angular/router';

@Component({
  selector: 'app-schedule-flight',
  templateUrl: './schedule-flight.component.html',
  styleUrls: ['./schedule-flight.component.css']
})
export class ScheduleFlightComponent implements OnInit {

  airportsData:Airport[]=[];

  flights:Flight[];

  Addedschedule:Schedule=new Schedule();

  scheduledFlight:ScheduledFlight=new ScheduledFlight();

  flight:Flight=new Flight();

  constructor(private service:DataService,private router:Router) { }

  ngOnInit(): void {

         this.service.viewAirport().subscribe(data=>this.airportsData=data);
          this.service.viewFlight().subscribe(data=>this.flights=data);


  }

   addSchedule():void{



          this.service.create(this.Addedschedule).subscribe(data=>this.Addedschedule=data);

         // this.router.navigateByUrl('/scheduleFlight1');

         alert("scheduled successfully");


   }



}
